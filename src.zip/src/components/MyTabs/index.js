import React,{useState} from 'react'
import { Tabs } from 'antd';
import Table from '../Table';
import axios from "axios"
import { v4 as uuidv4 } from "uuid";

function MyTabs(props) {
const {currentShop} = props;
const [startDayAndEndDay,setStartDayAndEndDay] =useState({
  startDay:"2023-02-23",
  endDay:"2023-03-01",
})
const url= "http://localhost:9000/employee/lists"
//根据地址
const onChange = (key) => {
  console.log(`现在是商店编号:${currentShop[0].id}的第${key}周`);
  setStartDayAndEndDay({
    startDay:`2023-02-25`,
    endDay:`2023-02-29`,
  })
};


const getDayItems = () =>{
  var items = [];
  for(var i = 0;i<10;i++){
    items.push(
      {
        key: i+1,
        label: `第${i+1}周`,
        children: <Table key={uuidv4()} style={{textAlign: 'center'}} currentShop={currentShop} startDayAndEndDay={startDayAndEndDay}></Table>,
      }
    )
  }
  return items
}

var myItems = getDayItems();

  return (<div>
    <h2>按周排班图</h2>
    <Tabs defaultActiveKey="1" items={myItems} onChange={onChange} />
    </div>
  )
}

export default MyTabs