import { Button, Input, Select } from "antd";
import { useState } from "react";
var __spreadArray =
  (this && this.__spreadArray) ||
  function (to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  };

var react_1 = require("react");
require("./index.css");
function Table(props) {
 const {currentShop,startDayAndEndDay} = props;
 console.log(currentShop);
 console.log(startDayAndEndDay);
 //2023.3.2 Quan Li
 //父组件传回当前商店的信息,和当前点按的日期的开始时间和结束时间
 //具体需要参数可以console.log()里面的消息
 //如要读取，使用currentShop[0].property...
 //例如currentShop[0].id,当前门店的编号


  // const handleOnClick3 = () => {
  //   // 获取当前修改内容的state
 
  //   const _a = { ...this.state._a}
  //   // 修改名字
  //   _a.value = Input()
  //   _a.user= event.target.user;
  //   const persons = [...this.state.persons]
  //   // 把当前修改过的值赋给对应下标的文本
  //   persons[presonIndex] = person;
  //   // 更新state内容
  //   this.setState({
  //     _a:_a
  //   })
  // };
  var day = [
    "星期日",
    "星期一",
    "星期二",
    "星期三",
    "星期四",
    "星期五",
    "星期六",
  ];
  var date = new Date();
  var _a = (0, react_1.useState)([
      [
        {
          time: "8:00-10:00",
          value: "门店经理",
          user: "张三",
        },
        {
          time: "8:00-10:00",
          value: "副经理",
          user: "李四",
        },
        {
          time: "8:00-10:00",
          value: "门店经理",
          user: "张三",
        },
        {
          time: "8:00-10:00",
          value: "副经理",
          user: "李四",
        },
        {
          time: "8:00-10:00",
          value: "门店经理",
          user: "张三",
        },
        {
          time: "8:00-10:00",
          value: "副经理",
          user: "李四",
        },
        {
          time: "8:00-10:00",
          value: "门店经理",
          user: "张三",
        },
      ],
      [
        {
          time: "10:00-12:00",
          value: "小组长",
          user: "王五",
        },
        {
          time: "10:00-12:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "10:00-12:00",
          value: "导购",
          user: "宋七",
        },
        {
          time: "10:00-12:00",
          value: "导购",
          user: "宋七",
        },
        {
          time: "10:00-12:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "10:00-12:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "10:00-12:00",
          value: "库房",
          user: "刘八",
        },
      ],
      [
        {
          time: "10:00-12:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "10:00-12:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "10:00-12:00",
          value: "导购",
          user: "宋七",
        },
        {
          time: "10:00-12:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "10:00-12:00",
          value: "小组长",
          user: "王五",
        },
        {
          time: "10:00-12:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "10:00-12:00",
          value: "导购",
          user: "宋七",
        },
      ],
      [
        {
          time: "10:00-12:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "10:00-12:00",
          value: "小组长",
          user: "王五",
        },
        {
          time: "10:00-12:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "10:00-12:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "10:00-12:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "10:00-12:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "10:00-12:00",
          value: "小组长",
          user: "王五",
        },
      ],
      [
        //
        {
          time: "12:00-14:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "12:00-14:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "12:00-14:00",
          value: "小组长",
          user: "王五",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "宋七",
        },
        {
          time: "12:00-14:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "12:00-14:00",
          value: "小组长",
          user: "王五",
        },
      ],
      [
        {
          time: "12:00-14:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "宋七",
        },
        {
          time: "12:00-14:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "12:00-14:00",
          value: "小组长",
          user: "王五",
        },
        {
          time: "12:00-14:00",
          value: "收银",
          user: "赵六",
        },
      ],
      [
        {
          time: "12:00-14:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "宋七",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "12:00-14:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "12:00-14:00",
          value: "小组长",
          user: "王五",
        },
      ],
      [
        {
          time: "12:00-14:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "12:00-14:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "12:00-14:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "宋七",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "唐十",
        },
      ],
      [
        {
          time: "12:00-14:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "12:00-14:00",
          value: "小组长",
          user: "王五",
        },
        {
          time: "12:00-14:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "12:00-14:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "宋七",
        },
        {
          time: "12:00-14:00",
          value: "导购",
          user: "崔九",
        },
      ],
      [
        {
          time: "14:00-16:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "14:00-16:00",
          value: "小组长",
          user: "王五",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "14:00-16:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "14:00-16:00",
          value: "小组长",
          user: "王五",
        },
      ],
      [
        {
          time: "14:00-16:00",
          value: "导购",
          user: "宋七",
        },
        {
          time: "14:00-16:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "14:00-16:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "崔九",
        },
      ],
      [
        {
          time: "14:00-16:00",
          value: "小组长",
          user: "王五",
        },
        {
          time: "14:00-16:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "14:00-16:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "宋七",
        },
        {
          time: "14:00-16:00",
          value: "小组长",
          user: "王五",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "崔九",
        },
      ],
      [
        {
          time: "14:00-16:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "14:00-16:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "14:00-16:00",
          value: "导购",
          user: "宋七",
        },
        {
          time: "14:00-16:00",
          value: "小组长",
          user: "王五",
        },
      ],
      [
        {
          time: "16:00-18:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "16:00-18:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "16:00-18:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "16:00-18:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "16:00-18:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "16:00-18:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "16:00-18:00",
          value: "小组长",
          user: "王五",
        },
      ],
      [
        {
          time: "16:00-18:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "16:00-18:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "16:00-18:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "16:00-18:00",
          value: "小组长",
          user: "王五",
        },
        {
          time: "16:00-18:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "16:00-18:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "16:00-18:00",
          value: "导购",
          user: "唐十",
        },
      ],
      [
        {
          time: "18:00-20:00",
          value: "小组长",
          user: "王五",
        },
        {
          time: "18:00-20:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "18:00-20:00",
          value: "小组长",
          user: "王五",
        },
        {
          time: "18:00-20:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "18:00-20:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "18:00-20:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "18:00-20:00",
          value: "导购",
          user: "崔九",
        },
      ],
      [
        {
          time: "18:00-20:00",
          value: "小组长",
          user: "王五",
        },
        {
          time: "18:00-20:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "18:00-20:00",
          value: "收银",
          user: "赵六",
        },
        {
          time: "18:00-20:00",
          value: "库房",
          user: "刘八",
        },
        {
          time: "18:00-20:00",
          value: "导购",
          user: "崔九",
        },
        {
          time: "18:00-20:00",
          value: "导购",
          user: "唐十",
        },
        {
          time: "18:00-20:00",
          value: "小组长",
          user: "王五",
        },
      ],
      [
        {
          time: "20:00-23:00",
          value: "副经理",
          user: "李四",
        },
        {
          time: "20:00-23:00",
          value: "门店经理",
          user: "张三",
        },
        {
          time: "20:00-23:00",
          value: "副经理",
          user: "李四",
        },
        {
          time: "20:00-23:00",
          value: "门店经理",
          user: "张三",
        },
        {
          time: "20:00-23:00",
          value: "副经理",
          user: "李四",
        },
        {
          time: "20:00-23:00",
          value: "门店经理",
          user: "张三",
        },
        {
          time: "20:00-23:00",
          value: "副经理",
          user: "李四",
        },
      ],
    ]),
    data = _a[0],
    setData = _a[1];
  var _b = (0, react_1.useState)([0, 0]),
    selectItem = _b[0],
    setSelectItem = _b[1];
  var _c = (0, react_1.useState)(1),
    seed = _c[0],
    setSeed = _c[1];
  var reset = function () {
    setSeed(Math.random());
  };
  var chargeValue = function (column, row) {
    console.log(column, row);
    setSelectItem([column, row]);
  };

  const [btnState, setBtnState] = useState(true);

  var editValue = function (value) {
    if (value === void 0) {
      value = "111";
    }
    console.log("edit");
    var cacheData = data;
    cacheData[selectItem[0]][selectItem[1]].value = value;
    setData(cacheData);
    reset();
  };

  var delBtn = function (value, user) {
    if (value === void 0) {
      value = "none";
    }
    if (user === void 0) {
      user = "none";
    }

    console.log("delBtn");

    var cacheData1 = data;
    cacheData1[selectItem[0]][selectItem[1]].value = value;
    cacheData1[selectItem[0]][selectItem[1]].user = user;
    setData(cacheData1);
    reset();
  };

  var getItemValue = function (column, row) {
    return (
      <div
        className={
          selectItem[0] === column && selectItem[1] === row
            ? "tableListSelect"
            : "tableList"
        }
        onClick={function () {
          return chargeValue(column, row);
        }}
      >
        <span> 时间: {data[column][row].time} </span>
        <span> 类别: {data[column][row].value} </span>
        <span> 用户: {data[column][row].user} </span>
      </div>
    );
  };
  var getDateList = function () {
    var today = date.getDay();
    return (
      <>
        {day.map(function (v, k) {
          return (
            <td className={k == today ? "dayToday" : "dayTable"}> {v} </td>
          );
        })}
      </>
    );
  };
  const [sltToggle, setSltToggle] = useState(false);
  return (
    <div className="App">
      <div className="head">
        <div className="left">
          {/* <select name="group" id="1">
                        <option value="0"> 按岗位分组</option>
                        <option value="1"> 按技能分组</option>
                        <option value="2"> 按员工分组</option>
                    </select> */}

          <Select
            defaultValue={0}
            style={{
              width: 120,
            }}
            options={[
              {
                value: 0,
                label: "按岗位分组",
              },
              {
                value: 1,
                label: "按技能分组",
              },
              {
                value: 2,
                label: "按员工分组",
              },
              {
                value: "disabled",
                label: "Disabled",
                disabled: true,
              },
            ]}
            onSelect={(value) => {
              if (value == 2) setSltToggle(true);
              else setSltToggle(false);
            }}
          />
          {sltToggle ? (
            <Select
              defaultValue={0}
              style={{
                width: 120,
              }}
              options={[
                {
                  value: 0,
                  label: "张三",
                },
                {
                  value: 1,
                  label: "李四",
                },
                {
                  value: 2,
                  label: "王五",
                },
              ]}
            />
          ) : (
            ""
          )}
        </div>
        <div className="right">
          <Button
            onClick={function () {
              return delBtn("none");
            }}
          >
            {" "}
            删除
          </Button>
          {btnState ? (
            <Button
              onClick={() => {
                var cacheData = data;

                setBtnState(!btnState);
                return editValue(
                  <input
                    type="text"
                    defaultValue={cacheData[selectItem[0]][selectItem[1]].value}
                    onChange={(e) => {
                      cacheData[selectItem[0]][selectItem[1]].value =
                        e.target.value;
                      setData(cacheData);
                    }}
                  ></input>
                );
              }}
            >
              编辑
            </Button>
          ) : (
            <Button
              onClick={() => {
                setBtnState(!btnState);
              }}
            >
              确定
            </Button>
          )}
        </div>
      </div>
      <table rules="all" border={1} frame={true} cellSpacing={10}>
        <thead>
          <tr>{getDateList()}</tr>
        </thead>
        <tbody key={seed}>
          {__spreadArray([], new Array(18), true).map(function (v, column) {
            return (
              <tr key={column}>
                {__spreadArray([], new Array(7), true).map(function (v, row) {
                  return (
                    <td className="dayTd" key={row}>
                      {" "}
                      {getItemValue(column, row)}{" "}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
export default Table;
